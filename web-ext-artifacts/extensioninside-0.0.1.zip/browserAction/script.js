document.getElementById('myHeading').style.color = 'blue';
